📁 **Updater Cache Folder**

Cache Folder for the Updater.

🐟 Bugfish <3
