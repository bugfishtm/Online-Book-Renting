📁 **Updater Rollback Folder**

Rollback Folder for the Updater.

🐟 Bugfish <3
