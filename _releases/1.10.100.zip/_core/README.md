📁 **Core Folder**

This folder houses Core System files and libraries to be used. Changes in this folder are not persistent between core updates. You can find much more information for development and use of modules in our documentation. You can find the documentation in the repositories _docs folder.

🐟 Bugfish <3
