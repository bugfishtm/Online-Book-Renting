📁 **Default Languages Folder**

Default Languages for the CMS Backend Structure are stored here.

de = german  
en = english  
es = spanish  
fr = french  
it = italian  
ja = japanese
zh = chinese

🐟 Bugfish <3
