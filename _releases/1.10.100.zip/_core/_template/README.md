📁 **Template Folder**

Templates for different types of modules and data folders to bee seen as documentation in the administrator interface.

🐟 Bugfish <3
