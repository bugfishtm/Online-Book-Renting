# Site Builder Library

In this folder you can store Site Builder Functionalities if your website is using that functionality imported out of the _administrator module. New Functionalities for the builders can be deployed here! See examples in _administrator Module WFC Folder if you want to develop own WFC Modules or check or official documentation.

Inside the official documentation you can find variables which are available with information for your module and site development!

🐟 Bugfish <3