# Trigger Files

This folder is dedicated to trigger files related to the administrator module. 

🐟 Bugfish <3