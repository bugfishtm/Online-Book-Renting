# Javascript Folder

The `_js` folder is designated for storing JavaScript files that are automatically loaded into the Suitefish via the HTML include at `/core/javascript.php`. This folder helps manage JavaScript code required for various functionalities.

JavaScript files in this folder are auto-loaded if the file name starts with js.*

Inside the official documentation you can find variables which are available with information for your module and site development!

🐟 Bugfish <3