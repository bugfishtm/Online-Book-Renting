# Administrator Module Injections

Files inside this folder will be injected in the official administrator module if necessary.

See our official documentation to get insights on which information is available for you to use while running cronjobs.  

🐟 Bugfish <3