# Theme Files

This folder is dedicated to storing files related to the users' templates. These files are essential for defining the appearance and structure of the user interface in Suitefish. 

These files are not directly related to the CMS and will not be auto included.

🐟 Bugfish <3