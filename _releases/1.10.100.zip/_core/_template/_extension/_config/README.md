# Configuration Folder

The `_config` folder contains configuration files that are crucial for initializing different sections of Suitefish CMS. These files are loaded at various stages of initialization to define settings, parameters, and behaviors.

🐟 Bugfish <3