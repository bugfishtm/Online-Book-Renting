# Worker Daemon Folder

**Use this area with caution as this scripts are running with full server root access (if you have installed this CMS using the background daemon)**

The `_worker` folder is dedicated to storing root daemon worker php files, to be executed when qeued into the system. The files must follow the naming convention `worker.*.php` to be recognized by the CMS.

See our official documentation to get insights on which information is available for you to use while running workers.  

🐟 Bugfish <3