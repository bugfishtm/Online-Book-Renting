# Languages Folder

The `_lang` folder is dedicated to storing language files to be loaded if the selected language is focused in the cms backend. The files must follow the naming convention `SHORTCODE.php` to be auto-included by the core system.

See examples to get more information on how this works.

See our official documentation to get insights on which information is available for you to use while running cronjobs.  

🐟 Bugfish <3