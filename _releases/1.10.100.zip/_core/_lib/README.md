📜 **Core Library**

Folder for Core Libraries like delivered themes or core procedures and subroutines.

🐟 Bugfish <3