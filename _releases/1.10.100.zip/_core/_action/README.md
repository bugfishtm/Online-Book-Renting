📁 **Actions Folder**

Folder for default Login and Execution Scripts and other core cms javascript and html actions!

🐟 Bugfish <3
