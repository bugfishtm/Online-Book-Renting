📁 **Core MySQL Folder**

Core MySQL Tables to be installed. You can find much more information for development and use of modules in our documentation. You can find the documentation in the repositories _docs folder.

🐟 Bugfish <3
