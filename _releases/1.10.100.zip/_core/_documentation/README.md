📁 **Documentation Folder**

Integrated Documentation for Suitefish-CMS.

🐟 Bugfish <3
