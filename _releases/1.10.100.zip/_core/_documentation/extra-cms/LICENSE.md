# License

This project’s documentation is built using MkDocs and the Material theme. The content, design, and layout of the documentation are licensed under the [MIT License](https://opensource.org/licenses/MIT). The MkDocs software and the Material theme are subject to their respective licenses, which are not covered by this project’s license.